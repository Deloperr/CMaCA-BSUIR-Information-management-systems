% Файл: mesh_function.m
function mesh_function()
    [x, y] = meshgrid(-5:0.1:5, -5:0.1:5); % создание массива данных
    z1 = my_function_2d_z1(x, y); % вызов функции z1
    z2 = my_function_2d_z2(x, y);
    figure;
    mesh(x, y, z1); % 3D график
    hold on;
    mesh(x, y, z2);
    title('График функции z = sin(y + 1) * y - x - 1');
    xlabel('x');
    ylabel('y');
    zlabel('z');
    grid on;
    hold off;
end
