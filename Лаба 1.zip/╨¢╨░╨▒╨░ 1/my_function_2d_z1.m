% Файл: my_function_2d_z1.m
function z1 = my_function_2d_z1(x, y)

    z1 = sinh(y+0.5)-x-2;
end
