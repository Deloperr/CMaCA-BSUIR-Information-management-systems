% Файл: plot_function.m
function plot_function()
    x = linspace(-10, 10, 100); % диапазон значений x
    y = my_function_1d(x); % вызов функции
    plot(x, y, 'm'); % построение графика
    title('График функции y = x*sin(x) - 5');
    xlabel('x');
    ylabel('y');
    grid on;
end
