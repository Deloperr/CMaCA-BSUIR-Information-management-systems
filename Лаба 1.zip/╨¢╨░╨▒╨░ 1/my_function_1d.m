% Файл: my_function_1d.m
function y = my_function_1d(x)
  
    y = sinh(x);
end
