% Файл: my_function_2d_z2.m
function z2 = my_function_2d_z2(x, y)
 
    z2 = sec(x)-2.*y-1;
end
