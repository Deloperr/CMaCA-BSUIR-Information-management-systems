% Файл: contour_functions.m
function contour_functions()
    [x, y] = meshgrid(-5:0.1:5, -5:0.1:5); % создание массива данных
    z1 = my_function_2d_z1(x, y); % вызов функции z1
    z2 = my_function_2d_z2(x, y); % вызов функции z2
    
    figure;
    contour(x, y, z1, 'ShowText', 'on'); % контурный график z1
    hold on;
    contour(x, y, z2, 'ShowText', 'on'); % контурный график z2
    title('Контурные графики функций z1 и z2');
    xlabel('x');
    ylabel('y');
    grid on;
    hold off;
end
