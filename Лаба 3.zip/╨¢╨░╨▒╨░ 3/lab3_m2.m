% Оригинальная функция
f = @(x) x .* sin(x) - 5;

% Параметры интерполяции
a = 0; % начало интервала
b = 5; % конец интервала
num_nodes = 5; % количество узлов интерполяции (можно изменить на 3, 4 или 5)

% Узлы интерполяции и значения функции в узлах
nodes = linspace(a, b, num_nodes);
values = f(nodes);

% Точки для построения графиков
x_plot = linspace(a, b, 100);
y_plot = f(x_plot);

% Вычисление интерполяционного полинома в каждой точке
L_plot = arrayfun(@(x) lab3_function1_m1(nodes, values, x), x_plot);

% Построение графиков
figure;
plot(x_plot, y_plot, 'b-', 'LineWidth', 1.5); % график оригинальной функции
hold on;
plot(x_plot, L_plot, 'r--', 'LineWidth', 1.5); % график интерполяционного полинома
plot(nodes, values, 'ko', 'MarkerFaceColor', 'k'); % узлы интерполяции
legend('Оригинальная функция', 'Интерполяционный полином', 'Узлы интерполяции');
title('Интерполяция полиномом Лагранжа');
xlabel('x');
ylabel('y');
grid on;
hold off;

% Исследование зависимости погрешности от количества узлов
num_nodes_list = 3:5;
error_list = zeros(size(num_nodes_list));

for k = 1:length(num_nodes_list)
    nodes_k = linspace(a, b, num_nodes_list(k));
    values_k = f(nodes_k);
    L_plot_k = arrayfun(@(x) lab3_function1_m1(nodes_k, values_k, x), x_plot);
    error_list(k) = max(abs(y_plot - L_plot_k)); % максимальная погрешность
end

% Вывод результатов погрешности
disp('Количество узлов и соответствующая погрешность:');
disp(table(num_nodes_list', error_list', 'VariableNames', {'Число_узлов', 'Макс_погрешность'}));