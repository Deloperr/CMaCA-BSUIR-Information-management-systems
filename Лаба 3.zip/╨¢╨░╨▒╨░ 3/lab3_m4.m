% Определение функции y = (x^3)*(e^(-x)) + 6x - 5
f = @(x) x .* sin(x) - 5;

% Параметры интерполяции
a = 0; % начало интервала
b = 5; % конец интервала
num_nodes = 5; % количество узлов интерполяции

% Узлы Чебышёва
chebyshev_nodes = (a + b)/2 + (b - a)/2 * cos((2*(1:num_nodes)-1) * pi / (2*num_nodes));
chebyshev_values = arrayfun(f, chebyshev_nodes);

% Узлы равномерной сетки
uniform_nodes = linspace(a, b, num_nodes);
uniform_values = arrayfun(f, uniform_nodes);

% Точки для построения графиков
x_plot = linspace(a, b, 100);
y_plot = arrayfun(f, x_plot);

% Интерполяция с использованием polyfit и polyval на узлах Чебышёва
degree = num_nodes - 1; % степень полинома
coeffs_chebyshev = polyfit(chebyshev_nodes, chebyshev_values, degree);
L_polyval_chebyshev = polyval(coeffs_chebyshev, x_plot); % значения полинома в точках x_plot

% Интерполяция с использованием polyfit и polyval на узлах равномерной сетки
coeffs_uniform = polyfit(uniform_nodes, uniform_values, degree);
L_polyval_uniform = polyval(coeffs_uniform, x_plot); % значения полинома в точках x_plot

% Построение графиков
figure;
plot(x_plot, y_plot, 'b-', 'LineWidth', 1.5); % график оригинальной функции
hold on;
plot(x_plot, L_polyval_chebyshev, 'g--', 'LineWidth', 1.5); % график интерполяции на узлах Чебышёва
plot(x_plot, L_polyval_uniform, 'r-.', 'LineWidth', 1.5); % график интерполяции на узлах равномерной сетки
plot(chebyshev_nodes, chebyshev_values, 'ko', 'MarkerFaceColor', 'k'); % узлы Чебышёва
plot(uniform_nodes, uniform_values, 'mo', 'MarkerFaceColor', 'm'); % узлы равномерной сетки
legend('Оригинальная функция', 'Интерполяция на узлах Чебышёва', 'Интерполяция на равномерной сетке', 'Узлы Чебышёва', 'Узлы равномерной сетки');
title('Сравнение интерполяции с узлами Чебышёва и равномерной сеткой');
xlabel('x');
ylabel('y');
grid on;
hold off;

% Исследование зависимости погрешности от количества узлов для узлов Чебышёва и равномерной сетки
num_nodes_list = 3:5;
error_list_chebyshev = zeros(size(num_nodes_list));
error_list_uniform = zeros(size(num_nodes_list));

for k = 1:length(num_nodes_list)
    % Узлы Чебышёва
    chebyshev_nodes_k = (a + b)/2 + (b - a)/2 * cos((2*(1:num_nodes_list(k))-1) * pi / (2*num_nodes_list(k)));
    chebyshev_values_k = arrayfun(f, chebyshev_nodes_k);
    coeffs_chebyshev_k = polyfit(chebyshev_nodes_k, chebyshev_values_k, num_nodes_list(k) - 1);
    L_plot_chebyshev_k = polyval(coeffs_chebyshev_k, x_plot);

    % Узлы равномерной сетки
    uniform_nodes_k = linspace(a, b, num_nodes_list(k));
    uniform_values_k = arrayfun(f, uniform_nodes_k);
    coeffs_uniform_k = polyfit(uniform_nodes_k, uniform_values_k, num_nodes_list(k) - 1);
    L_plot_uniform_k = polyval(coeffs_uniform_k, x_plot);

    % Погрешности
    error_list_chebyshev(k) = max(abs(y_plot - L_plot_chebyshev_k)); % максимальная погрешность на узлах Чебышёва
    error_list_uniform(k) = max(abs(y_plot - L_plot_uniform_k)); % максимальная погрешность на узлах равномерной сетки
end

% Вывод результатов погрешности
disp('Количество узлов и соответствующие погрешности:');
disp(table(num_nodes_list', error_list_chebyshev', error_list_uniform', 'VariableNames', {'Число_узлов', 'Погрешность_Чебышёв', 'Погрешность_равномерная'}));