% Определение функции y = (x^3)*(e^(-x)) + 6x - 5
f = @(x) x .* sin(x) - 5;

% Параметры интерполяции
a = 0; % начало интервала
b = 5; % конец интервала
num_nodes = 5; % количество узлов интерполяции

% Узлы интерполяции и значения функции в узлах
nodes = linspace(a, b, num_nodes);
values = arrayfun(f, nodes);

% Точки для построения графиков
x_plot = linspace(a, b, 100);
y_plot = arrayfun(f, x_plot);

% Интерполяция с использованием polyfit и polyval
degree = num_nodes - 1; % степень полинома
coeffs = polyfit(nodes, values, degree); % коэффициенты полинома
L_polyval = polyval(coeffs, x_plot); % значения полинома в точках x_plot

% Построение графиков
figure;
plot(x_plot, y_plot, 'b-', 'LineWidth', 1.5); % график оригинальной функции
hold on;
plot(x_plot, L_polyval, 'g--', 'LineWidth', 1.5); % график интерполяции polyfit/polyval
plot(nodes, values, 'ko', 'MarkerFaceColor', 'k'); % узлы интерполяции
legend('Оригинальная функция', 'Интерполяция polyfit/polyval', 'Узлы интерполяции');
title('Интерполяция полиномом с использованием polyfit/polyval');
xlabel('x');
ylabel('y');
grid on;
hold off;

% Исследование зависимости погрешности от количества узлов для polyfit/polyval
num_nodes_list = 3:5;
error_list_polyval = zeros(size(num_nodes_list));
error_list_custom = zeros(size(num_nodes_list));

for k = 1:length(num_nodes_list)
    nodes_k = linspace(a, b, num_nodes_list(k));
    values_k = arrayfun(f, nodes_k);
    degree_k = num_nodes_list(k) - 1;
    coeffs_k = polyfit(nodes_k, values_k, degree_k);
    L_plot_polyval_k = polyval(coeffs_k, x_plot);
    L_plot_custom_k = arrayfun(@(x) lab3_function1_m1(nodes_k, values_k, x), x_plot);
    error_list_polyval(k) = max(abs(y_plot - L_plot_polyval_k)); % максимальная погрешность polyfit/polyval
    error_list_custom(k) = max(abs(y_plot - L_plot_custom_k)); % максимальная погрешность собственной функции
end

% Вывод результатов погрешности
disp('Количество узлов и соответствующие погрешности:');
disp(table(num_nodes_list', error_list_polyval', error_list_custom', 'VariableNames', {'Число_узлов', 'Погрешность_polyval', 'Погрешность_собственной'}));